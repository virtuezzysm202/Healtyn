import { Ionicons } from "@expo/vector-icons";
import DateTimePicker from "@react-native-community/datetimepicker";
import * as ImagePicker from "expo-image-picker";
import * as Notifications from "expo-notifications";
import React, { useEffect, useState } from "react";
import {
  Alert,
  Dimensions,
  Image,
  Platform,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from "react-native";
import AdaptivePicker from "../../components/AdaptivePicker";

const { width } = Dimensions.get('window');

// Notification handler
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

interface MedicineSchedule {
  id: string;
  medicineName: string;
  medicineType: string;
  disease: string;
  medicineForm: string;
  dosageAmount: string;
  dosageUnit: string;
  spoonSize?: string;
  notes: string;
  usageTime: string;
  timesPerDay: number;
  alarmTimes: Date[];
  mustFinish: boolean;
  startDate: Date;
  endDate: Date;
  medicineImage?: string;
  isActive: boolean;
  lastTaken?: Date;
}

export default function MedicineScreen() {
  const [currentView, setCurrentView] = useState<'main' | 'create' | 'detail'>('main');
  const [selectedSchedule, setSelectedSchedule] = useState<MedicineSchedule | null>(null);
  const [savedSchedules, setSavedSchedules] = useState<MedicineSchedule[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  // Form states
  const [medicineName, setMedicineName] = useState("");
  const [medicineType, setMedicineType] = useState("");
  const [disease, setDisease] = useState("");
  const [medicineForm, setMedicineForm] = useState("");
  const [dosageAmount, setDosageAmount] = useState("");
  const [dosageUnit, setDosageUnit] = useState("");
  const [spoonSize, setSpoonSize] = useState("");
  const [notes, setNotes] = useState("");
  const [usageTime, setUsageTime] = useState("");
  const [timesPerDay, setTimesPerDay] = useState(1);
  const [mustFinish, setMustFinish] = useState(false);
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());
  const [medicineImage, setMedicineImage] = useState<string | null>(null);
  const [alarmTimes, setAlarmTimes] = useState([new Date()]);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [selectedTimeIndex, setSelectedTimeIndex] = useState(0);
  const [showStartDatePicker, setShowStartDatePicker] = useState(false);
  const [showEndDatePicker, setShowEndDatePicker] = useState(false);

  const medicineTypes = [
    { label: "Antibiotik", value: "antibiotik" },
    { label: "Analgesik", value: "analgesik" },
    { label: "Antiinflamasi", value: "antiinflamasi" },
    { label: "Antasida", value: "antasida" },
    { label: "Vitamin", value: "vitamin" },
    { label: "Suplemen", value: "suplemen" },
    { label: "Herbal", value: "herbal" },
    { label: "Lainnya", value: "lainnya" },
  ];

  const diseases = [
    { label: "Demam", value: "demam" },
    { label: "Batuk", value: "batuk" },
    { label: "Flu", value: "flu" },
    { label: "Sakit Kepala", value: "sakit_kepala" },
    { label: "Diare", value: "diare" },
    { label: "Maag", value: "maag" },
    { label: "Hipertensi", value: "hipertensi" },
    { label: "Diabetes", value: "diabetes" },
    { label: "Asma", value: "asma" },
    { label: "Alergi", value: "alergi" },
    { label: "Lainnya", value: "lainnya" },
  ];

  const medicineForms = [
    { label: "Tablet", value: "tablet" },
    { label: "Kapsul", value: "kapsul" },
    { label: "Sirup", value: "sirup" },
    { label: "Tetes", value: "tetes" },
    { label: "Salep", value: "salep" },
    { label: "Inhaler", value: "inhaler" },
    { label: "Suntikan", value: "injection" },
    { label: "Bubuk", value: "bubuk" },
  ];

  const spoonSizes = [
    { label: "Sendok Teh (5ml)", value: "sendok_teh" },
    { label: "Sendok Makan (15ml)", value: "sendok_makan" },
    { label: "Sendok Takar", value: "sendok_takar" },
  ];

  // Check schedule status on component mount and refresh
  useEffect(() => {
    checkScheduleStatus();
  }, [savedSchedules]);

  // Check which schedules are currently active
  const checkScheduleStatus = () => {
    const now = new Date();
    const updatedSchedules = savedSchedules.map(schedule => {
      const isActive = now >= schedule.startDate && now <= schedule.endDate;
      return { ...schedule, isActive };
    });
    
    if (JSON.stringify(updatedSchedules) !== JSON.stringify(savedSchedules)) {
      setSavedSchedules(updatedSchedules);
    }
  };

  // Get today's schedules
  const getTodaySchedules = () => {
    return savedSchedules.filter(schedule => schedule.isActive);
  };

  // Get next upcoming medicine time
  const getNextMedicineTime = (schedule: MedicineSchedule) => {
    const now = new Date();
    const todayTimes = schedule.alarmTimes.map(time => {
      const nextTime = new Date();
      nextTime.setHours(time.getHours(), time.getMinutes(), 0, 0);
      return nextTime;
    }).sort((a, b) => a.getTime() - b.getTime());

    // Find next time today
    for (const time of todayTimes) {
      if (time > now) {
        return time;
      }
    }

    // If no time left today, return first time tomorrow
    const tomorrowTime = new Date(todayTimes[0]);
    tomorrowTime.setDate(tomorrowTime.getDate() + 1);
    return tomorrowTime;
  };

  // Mark medicine as taken
  const markAsTaken = (scheduleId: string) => {
    setSavedSchedules(prevSchedules =>
      prevSchedules.map(schedule =>
        schedule.id === scheduleId
          ? { ...schedule, lastTaken: new Date() }
          : schedule
      )
    );
    Alert.alert("Berhasil", "Obat telah ditandai sudah diminum!");
  };

  // Delete schedule
  const deleteSchedule = (scheduleId: string) => {
    Alert.alert(
      "Hapus Jadwal",
      "Apakah Anda yakin ingin menghapus jadwal obat ini?",
      [
        { text: "Batal", style: "cancel" },
        {
          text: "Hapus",
          style: "destructive",
          onPress: () => {
            setSavedSchedules(prevSchedules =>
              prevSchedules.filter(schedule => schedule.id !== scheduleId)
            );
            // Cancel notifications for this schedule
            cancelNotifications(scheduleId);
          }
        }
      ]
    );
  };

  // Cancel notifications
  const cancelNotifications = async (scheduleId: string) => {
    try {
      const scheduledNotifications = await Notifications.getAllScheduledNotificationsAsync();
      const medicineNotifications = scheduledNotifications.filter(
        notif => notif.content.data?.medicineId === scheduleId
      );
      
      for (const notif of medicineNotifications) {
        await Notifications.cancelScheduledNotificationAsync(notif.identifier);
      }
    } catch (error) {
      console.error('Error canceling notifications:', error);
    }
  };

  // Reset form
  const resetForm = () => {
    setMedicineName("");
    setMedicineType("");
    setDisease("");
    setMedicineForm("");
    setDosageAmount("");
    setDosageUnit("");
    setSpoonSize("");
    setNotes("");
    setUsageTime("");
    setTimesPerDay(1);
    setMustFinish(false);
    setStartDate(new Date());
    setEndDate(new Date());
    setMedicineImage(null);
    setAlarmTimes([new Date()]);
  };

  // Handle refresh
  const onRefresh = () => {
    setRefreshing(true);
    checkScheduleStatus();
    setTimeout(() => {
      setRefreshing(false);
    }, 1000);
  };

  // Handle times per day change
  const handleTimesPerDayChange = (times: number) => {
    setTimesPerDay(times);
    const newAlarmTimes = [];
    for (let i = 0; i < times; i++) {
      const time = new Date();
      time.setHours(8 + (i * 4), 0, 0, 0); // More realistic intervals: 8AM, 12PM, 4PM, 8PM, etc.
      newAlarmTimes.push(time);
    }
    setAlarmTimes(newAlarmTimes);
  };

  // Pick image
  const pickImage = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    
    if (permissionResult.granted === false) {
      Alert.alert("Izin Diperlukan", "Mohon izinkan akses galeri untuk menambah foto obat.");
      return;
    }

    Alert.alert(
      "Pilih Foto Obat",
      "Pilih sumber foto obat",
      [
        { text: "Kamera", onPress: openCamera },
        { text: "Galeri", onPress: openGallery },
        { text: "Batal", style: "cancel" }
      ]
    );
  };

  const openCamera = async () => {
    const permissionResult = await ImagePicker.requestCameraPermissionsAsync();
    if (permissionResult.granted === false) {
      Alert.alert("Izin Diperlukan", "Mohon izinkan akses kamera untuk mengambil foto obat.");
      return;
    }

    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 0.8,
    });

    if (!result.canceled) {
      setMedicineImage(result.assets[0].uri);
    }
  };

  const openGallery = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 0.8,
    });

    if (!result.canceled) {
      setMedicineImage(result.assets[0].uri);
    }
  };

  // Update alarm time
  const updateAlarmTime = (index: number, newTime: Date) => {
    const newTimes = [...alarmTimes];
    newTimes[index] = newTime;
    setAlarmTimes(newTimes);
  };

  // Save medicine schedule
  const saveMedicineSchedule = async () => {
    if (!medicineName.trim()) {
      Alert.alert("Error", "Nama obat wajib diisi!");
      return;
    }
    if (!medicineType.trim()) {
      Alert.alert("Error", "Jenis obat wajib diisi!");
      return;
    }
    if (!disease.trim()) {
      Alert.alert("Error", "Penyakit wajib diisi!");
      return;
    }
    if (!medicineForm.trim()) {
      Alert.alert("Error", "Bentuk obat wajib diisi!");
      return;
    }
    if (!dosageAmount.trim()) {
      Alert.alert("Error", "Dosis wajib diisi!");
      return;
    }
    if (!usageTime.trim()) {
      Alert.alert("Error", "Waktu minum/pakai wajib diisi!");
      return;
    }

    const now = new Date();
    const isActive = now >= startDate && now <= endDate;

    const newSchedule: MedicineSchedule = {
      id: Date.now().toString(),
      medicineName,
      medicineType,
      disease,
      medicineForm,
      dosageAmount,
      dosageUnit,
      spoonSize,
      notes,
      usageTime,
      timesPerDay,
      alarmTimes: [...alarmTimes],
      mustFinish,
      startDate: new Date(startDate),
      endDate: new Date(endDate),
      medicineImage: medicineImage || undefined,
      isActive,
    };

    setSavedSchedules([...savedSchedules, newSchedule]);
    
    // Schedule notifications
    await scheduleNotifications(newSchedule);
    
    Alert.alert("Berhasil", "Jadwal obat berhasil disimpan!", [
      { text: "OK", onPress: () => {
        resetForm();
        setCurrentView('main');
      }}
    ]);
  };

  // Schedule notifications
  const scheduleNotifications = async (schedule: MedicineSchedule) => {
    const { status } = await Notifications.requestPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Izin Diperlukan', 'Mohon aktifkan notifikasi untuk pengingat obat.');
      return;
    }

    try {
      for (let i = 0; i < schedule.alarmTimes.length; i++) {
        const time = schedule.alarmTimes[i];
        await Notifications.scheduleNotificationAsync({
          content: {
            title: "Waktu Minum Obat!",
            body: `Saatnya minum ${schedule.medicineName} - ${schedule.dosageAmount} ${schedule.dosageUnit}`,
            data: { medicineId: schedule.id },
          },
          trigger: {
            type: "calendar",
            hour: time.getHours(),
            minute: time.getMinutes(),
            repeats: true,
          } as Notifications.CalendarTriggerInput,
        });
      }
    } catch (error) {
      console.error('Error scheduling notifications:', error);
    }
  };

  // Render dosage input based on medicine form
  const renderDosageInput = () => {
    if (medicineForm === "tablet" || medicineForm === "kapsul") {
      return (
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Dosis Sekali Minum</Text>
          <View style={styles.inputContainer}>
            <Ionicons name="medical" size={20} color="#007AFF" />
            <TextInput
              style={styles.input}
              placeholder="Masukkan jumlah (contoh: 1, 0.5, 2)"
              keyboardType="numeric"
              value={dosageAmount}
              onChangeText={(text) => {
                setDosageAmount(text);
                setDosageUnit(medicineForm);
              }}
              placeholderTextColor="#C7C7CC"
            />
            <Text style={styles.unitText}>{medicineForm}</Text>
          </View>
        </View>
      );
    } else if (medicineForm === "sirup" || medicineForm === "tetes") {
      return (
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Dosis Sekali Minum</Text>
          <View style={styles.dosageContainer}>
            <View style={styles.inputContainer}>
              <Ionicons name="water" size={20} color="#007AFF" />
              <TextInput
                style={styles.input}
                placeholder="Jumlah (contoh: 1, 2, 0.5)"
                keyboardType="numeric"
                value={dosageAmount}
                onChangeText={setDosageAmount}
                placeholderTextColor="#C7C7CC"
              />
            </View>
            
            <View style={styles.pickerWrapper}>
              <AdaptivePicker
                label="Pilih Ukuran"
                selectedValue={spoonSize}
                onValueChange={(value) => {
                  setSpoonSize(value);
                  const selectedSpoon = spoonSizes.find(s => s.value === value);
                  setDosageUnit(selectedSpoon?.label || "sendok");
                }}
                items={spoonSizes}
              />
            </View>
          </View>
          
          <View style={styles.inputContainer}>
            <Ionicons name="flask" size={20} color="#007AFF" />
            <TextInput
              style={styles.input}
              placeholder="Atau masukkan dalam ml (opsional)"
              keyboardType="numeric"
              placeholderTextColor="#C7C7CC"
            />
            <Text style={styles.unitText}>ml</Text>
          </View>
        </View>
      );
    } else {
      return (
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Dosis Sekali Pakai</Text>
          <View style={styles.inputContainer}>
            <Ionicons name="medical" size={20} color="#007AFF" />
            <TextInput
              style={styles.input}
              placeholder="Masukkan dosis (contoh: 1 tube, secukupnya)"
              value={dosageAmount}
              onChangeText={(text) => {
                setDosageAmount(text);
                setDosageUnit("");
              }}
              placeholderTextColor="#C7C7CC"
            />
          </View>
        </View>
      );
    }
  };

  // Render times per day selector
  const renderTimesPerDaySelector = () => (
    <View style={styles.section}>
      <Text style={styles.sectionLabel}>Frekuensi Per Hari</Text>
      <View style={styles.frequencyContainer}>
        {[1, 2, 3, 4, 5, 6].map((times) => (
          <TouchableOpacity
            key={times}
            style={[
              styles.frequencyButton,
              timesPerDay === times && styles.frequencyButtonActive
            ]}
            onPress={() => handleTimesPerDayChange(times)}
          >
            <Text style={[
              styles.frequencyButtonText,
              timesPerDay === times && styles.frequencyButtonTextActive
            ]}>
              {times}x
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  // Render alarm times
  const renderAlarmTimes = () => (
    <View style={styles.section}>
      <Text style={styles.sectionLabel}>Waktu Pengingat ({timesPerDay}x sehari)</Text>
      {alarmTimes.slice(0, timesPerDay).map((time, index) => (
        <View key={index} style={styles.alarmTimeContainer}>
          <View style={styles.timeDisplayContainer}>
            <View style={styles.timeIcon}>
              <Ionicons name="time" size={18} color="#007AFF" />
            </View>
            <View style={styles.timeInfo}>
              <Text style={styles.timeText}>
                {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </Text>
              <Text style={styles.timeSubtext}>Pengingat ke-{index + 1}</Text>
            </View>
          </View>
          <TouchableOpacity
            onPress={() => {
              setSelectedTimeIndex(index);
              setShowTimePicker(true);
            }}
            style={styles.actionButton}
          >
            <Ionicons name="pencil" size={16} color="#007AFF" />
          </TouchableOpacity>
        </View>
      ))}

      {showTimePicker && (
        <DateTimePicker
          value={alarmTimes[selectedTimeIndex]}
          mode="time"
          is24Hour={true}
          display="default"
          onChange={(event, selectedTime) => {
            setShowTimePicker(Platform.OS === 'ios');
            if (selectedTime) {
              updateAlarmTime(selectedTimeIndex, selectedTime);
            }
          }}
        />
      )}
    </View>
  );

  // Render date picker
  const renderDatePicker = (
    label: string, 
    date: Date, 
    setDate: (d: Date) => void, 
    showPicker: boolean, 
    setShowPicker: (show: boolean) => void
  ) => {
    if (Platform.OS === "web") {
      return (
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>{label}</Text>
          <View style={styles.webInputContainer}>
            <input
              type="date"
              value={date.toISOString().split("T")[0]}
              onChange={(e) => setDate(new Date(e.target.value))}
              style={{
                fontSize: 16,
                border: "none",
                outline: "none",
                width: "100%",
                backgroundColor: "transparent",
                color: "#000000",
                padding: "8px 0",
              }}
            />
          </View>
        </View>
      );
    } else {
      return (
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>{label}</Text>
          <TouchableOpacity 
            style={styles.dateButton} 
            onPress={() => setShowPicker(true)}
          >
            <View style={styles.dateButtonContent}>
              <Ionicons name="calendar" size={20} color="#007AFF" />
              <Text style={styles.dateButtonText}>
                {date.toLocaleDateString('id-ID', { 
                  weekday: 'long',
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={16} color="#C7C7CC" />
          </TouchableOpacity>
          
          {showPicker && (
            <DateTimePicker
              value={date}
              mode="date"
              display="default"
              onChange={(_, selectedDate) => {
                setShowPicker(false);
                if (selectedDate) setDate(selectedDate);
              }}
            />
          )}
        </View>
      );
    }
  };

  // Render schedule card for main view
  const renderScheduleCard = ({ item }: { item: MedicineSchedule }) => {
    const nextTime = getNextMedicineTime(item);
    const isToday = nextTime.toDateString() === new Date().toDateString();
    const timeText = isToday 
      ? `Selanjutnya: ${nextTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
      : `Besok: ${nextTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

    return (
      <TouchableOpacity
        style={[styles.scheduleCard, !item.isActive && styles.inactiveCard]}
        onPress={() => {
          setSelectedSchedule(item);
          setCurrentView('detail');
        }}
      >
        <View style={styles.cardHeader}>
          <View style={styles.cardHeaderLeft}>
            {item.medicineImage && (
              <Image source={{ uri: item.medicineImage }} style={styles.cardImage} />
            )}
            <View style={styles.cardTitleContainer}>
              <Text style={styles.cardTitle}>{item.medicineName}</Text>
              <Text style={styles.cardSubtitle}>
                {item.dosageAmount} {item.dosageUnit} • {item.timesPerDay}x sehari
              </Text>
              {item.isActive ? (
                <Text style={styles.nextTimeText}>{timeText}</Text>
              ) : (
                <Text style={styles.inactiveText}>Tidak aktif</Text>
              )}
            </View>
          </View>
          <View style={styles.cardActions}>
            {item.isActive && (
              <TouchableOpacity
                style={styles.takeButton}
                onPress={() => markAsTaken(item.id)}
              >
                <Ionicons name="checkmark" size={16} color="#FFFFFF" />
              </TouchableOpacity>
            )}
          </View>
        </View>

        {item.isActive && (
          <View style={styles.timesContainer}>
            {item.alarmTimes.slice(0, item.timesPerDay).map((time, index) => (
              <View key={index} style={styles.timeBadge}>
                <Text style={styles.timeBadgeText}>
                  {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </Text>
              </View>
            ))}
          </View>
        )}
      </TouchableOpacity>
    );
  };

  // Render main screen with schedules
  const renderMainScreen = () => {
    const activeSchedules = getTodaySchedules();
    const inactiveSchedules = savedSchedules.filter(s => !s.isActive);

    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>Pengingat Obat</Text>
          <Text style={styles.subtitle}>
            {activeSchedules.length} obat aktif • {savedSchedules.length} total jadwal
          </Text>
        </View>
        
        <ScrollView
          style={styles.content}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor="#007AFF"
              colors={['#007AFF']}
            />
          }
        >
          {/* Quick Action Button */}
          <View style={styles.quickActionContainer}>
            <TouchableOpacity 
              style={styles.addButton}
              onPress={() => setCurrentView('create')}
            >
              <Ionicons name="add" size={24} color="#FFFFFF" />
              <Text style={styles.addButtonText}>Tambah Jadwal Obat</Text>
            </TouchableOpacity>
          </View>

          {savedSchedules.length === 0 ? (
            /* Empty State */
            <View style={styles.emptyState}>
              <Ionicons name="medical-outline" size={64} color="#C7C7CC" />
              <Text style={styles.emptyStateTitle}>Belum Ada Jadwal Obat</Text>
              <Text style={styles.emptyStateSubtitle}>
                Mulai buat jadwal obat pertama Anda untuk mendapatkan pengingat yang tepat waktu
              </Text>
            </View>
          ) : (
            <>
              {/* Active Schedules */}
              {activeSchedules.length > 0 && (
                <View style={styles.sectionContainer}>
                  <Text style={styles.sectionTitle}>Obat Aktif Hari Ini</Text>
                  {activeSchedules.map((schedule) => (
                    <View key={schedule.id}>
                      {renderScheduleCard({ item: schedule })}
                    </View>
                  ))}
                </View>
              )}

              {/* Inactive Schedules */}
              {inactiveSchedules.length > 0 && (
                <View style={styles.sectionContainer}>
                  <Text style={styles.sectionTitle}>Jadwal Lainnya</Text>
                  {inactiveSchedules.map((schedule) => (
                    <View key={schedule.id}>
                      {renderScheduleCard({ item: schedule })}
                    </View>
                  ))}
                </View>
              )}
            </>
          )}

          <View style={styles.bottomPadding} />
        </ScrollView>
      </View>
    );
  };

  // Render detail view
  const renderDetailView = () => {
    if (!selectedSchedule) return null;

    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => setCurrentView('main')}
          >
            <Ionicons name="chevron-back" size={24} color="#FFFFFF" />
          </TouchableOpacity>
          <Text style={styles.title}>Detail Obat</Text>
          <TouchableOpacity 
            style={styles.deleteButton}
            onPress={() => deleteSchedule(selectedSchedule.id)}
          >
            <Ionicons name="trash" size={20} color="#FFFFFF" />
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {selectedSchedule.medicineImage && (
            <View style={styles.detailImageContainer}>
              <Image 
                source={{ uri: selectedSchedule.medicineImage }} 
                style={styles.detailImage} 
              />
            </View>
          )}

          <View style={styles.detailContent}>
            <View style={styles.detailHeader}>
              <Text style={styles.detailTitle}>{selectedSchedule.medicineName}</Text>
              <View style={[
                styles.statusBadge, 
                selectedSchedule.isActive ? styles.activeBadge : styles.inactiveBadge
              ]}>
                <Text style={[
                  styles.statusText,
                  selectedSchedule.isActive ? styles.activeText : styles.inactiveStatusText
                ]}>
                  {selectedSchedule.isActive ? 'Aktif' : 'Tidak Aktif'}
                </Text>
              </View>
            </View>

            <View style={styles.detailSection}>
              <Text style={styles.detailLabel}>Informasi Obat</Text>
              <View style={styles.detailRow}>
                <Text style={styles.detailKey}>Jenis:</Text>
                <Text style={styles.detailValue}>{selectedSchedule.medicineType}</Text>
              </View>
              <View style={styles.detailRow}>
                <Text style={styles.detailKey}>Untuk:</Text>
                <Text style={styles.detailValue}>{selectedSchedule.disease}</Text>
              </View>
              <View style={styles.detailRow}>
                <Text style={styles.detailKey}>Bentuk:</Text>
                <Text style={styles.detailValue}>{selectedSchedule.medicineForm}</Text>
              </View>
            </View>

            <View style={styles.detailSection}>
              <Text style={styles.detailLabel}>Dosis & Jadwal</Text>
              <View style={styles.detailRow}>
                <Text style={styles.detailKey}>Dosis:</Text>
                <Text style={styles.detailValue}>
                  {selectedSchedule.dosageAmount} {selectedSchedule.dosageUnit}
                </Text>
              </View>
              <View style={styles.detailRow}>
                <Text style={styles.detailKey}>Frekuensi:</Text>
                <Text style={styles.detailValue}>{selectedSchedule.timesPerDay}x sehari</Text>
              </View>
              <View style={styles.detailRow}>
                <Text style={styles.detailKey}>Waktu:</Text>
                <Text style={styles.detailValue}>{selectedSchedule.usageTime}</Text>
              </View>
            </View>

            <View style={styles.detailSection}>
              <Text style={styles.detailLabel}>Waktu Pengingat</Text>
              <View style={styles.alarmTimesGrid}>
                {selectedSchedule.alarmTimes.slice(0, selectedSchedule.timesPerDay).map((time, index) => (
                  <View key={index} style={styles.alarmTimeCard}>
                    <Ionicons name="time" size={16} color="#007AFF" />
                    <Text style={styles.alarmTimeText}>
                      {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </Text>
                  </View>
                ))}
              </View>
            </View>

            <View style={styles.detailSection}>
              <Text style={styles.detailLabel}>Periode Pengobatan</Text>
              <View style={styles.dateRange}>
                <View style={styles.dateRangeItem}>
                  <Text style={styles.dateRangeLabel}>Mulai</Text>
                  <Text style={styles.dateRangeValue}>
                    {selectedSchedule.startDate.toLocaleDateString('id-ID')}
                  </Text>
                </View>
                <Ionicons name="arrow-forward" size={16} color="#8E8E93" />
                <View style={styles.dateRangeItem}>
                  <Text style={styles.dateRangeLabel}>Selesai</Text>
                  <Text style={styles.dateRangeValue}>
                    {selectedSchedule.endDate.toLocaleDateString('id-ID')}
                  </Text>
                </View>
              </View>
            </View>

            {selectedSchedule.mustFinish && (
              <View style={styles.detailSection}>
                <View style={styles.mustFinishContainer}>
                  <Ionicons name="checkmark-circle" size={20} color="#34C759" />
                  <Text style={styles.mustFinishDetailText}>Obat ini harus dihabiskan</Text>
                </View>
              </View>
            )}

            {selectedSchedule.notes && (
              <View style={styles.detailSection}>
                <Text style={styles.detailLabel}>Catatan</Text>
                <Text style={styles.notesText}>{selectedSchedule.notes}</Text>
              </View>
            )}

            {selectedSchedule.lastTaken && (
              <View style={styles.detailSection}>
                <Text style={styles.detailLabel}>Terakhir Diminum</Text>
                <Text style={styles.lastTakenText}>
                  {selectedSchedule.lastTaken.toLocaleDateString('id-ID')} • {' '}
                  {selectedSchedule.lastTaken.toLocaleTimeString([], { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                </Text>
              </View>
            )}

            {selectedSchedule.isActive && (
              <View style={styles.actionContainer}>
                <TouchableOpacity
                  style={styles.takenButton}
                  onPress={() => markAsTaken(selectedSchedule.id)}
                >
                  <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                  <Text style={styles.takenButtonText}>Tandai Sudah Diminum</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>

          <View style={styles.bottomPadding} />
        </ScrollView>
      </View>
    );
  };

  // Render create form
  const renderCreateForm = () => (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => setCurrentView('main')}
        >
          <Ionicons name="chevron-back" size={24} color="#FFFFFF" />
        </TouchableOpacity>
        <Text style={styles.title}>Buat Jadwal Obat</Text>
        <Text style={styles.subtitle}>Isi detail obat dan jadwal</Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Medicine Photo */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Foto Obat (Opsional)</Text>
          <TouchableOpacity style={styles.imageContainer} onPress={pickImage}>
            {medicineImage ? (
              <View style={styles.imageWrapper}>
                <Image source={{ uri: medicineImage }} style={styles.medicineImage} />
                <View style={styles.imageOverlay}>
                  <Ionicons name="camera" size={24} color="#FFFFFF" />
                </View>
              </View>
            ) : (
              <View style={styles.imagePlaceholder}>
                <View style={styles.cameraIcon}>
                  <Ionicons name="camera-outline" size={32} color="#007AFF" />
                </View>
                <Text style={styles.imagePlaceholderText}>Tambah Foto Obat</Text>
                <Text style={styles.imagePlaceholderSubtext}>Tap untuk memilih foto</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>

        {/* Medicine Name */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Nama Obat *</Text>
          <View style={styles.inputContainer}>
            <Ionicons name="medical" size={20} color="#007AFF" />
            <TextInput
              style={styles.input}
              placeholder="Masukkan nama obat"
              value={medicineName}
              onChangeText={setMedicineName}
              placeholderTextColor="#C7C7CC"
            />
          </View>
        </View>

        {/* Medicine Type */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Jenis Obat *</Text>
          <View style={styles.pickerWrapper}>
            <AdaptivePicker
              label="Pilih Jenis Obat"
              selectedValue={medicineType}
              onValueChange={setMedicineType}
              items={medicineTypes}
            />
          </View>
        </View>

        {/* Disease */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Untuk Penyakit *</Text>
          <View style={styles.pickerWrapper}>
            <AdaptivePicker
              label="Pilih Penyakit"
              selectedValue={disease}
              onValueChange={setDisease}
              items={diseases}
            />
          </View>
        </View>

        {/* Medicine Form */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Bentuk Obat *</Text>
          <View style={styles.pickerWrapper}>
            <AdaptivePicker
              label="Pilih Bentuk Obat"
              selectedValue={medicineForm}
              onValueChange={(value) => {
                setMedicineForm(value);
                setDosageAmount("");
                setDosageUnit("");
                setSpoonSize("");
              }}
              items={medicineForms}
            />
          </View>
        </View>

        {/* Dosage Input */}
        {medicineForm && renderDosageInput()}

        {/* Notes */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Catatan (Opsional)</Text>
          <View style={styles.notesContainer}>
            <Ionicons name="document-text-outline" size={20} color="#007AFF" />
            <TextInput
              value={notes}
              onChangeText={setNotes}
              style={styles.notesInput}
              placeholder="Tambahan informasi atau catatan khusus"
              multiline
              textAlignVertical="top"
              placeholderTextColor="#C7C7CC"
            />
          </View>
        </View>

        {/* Usage Time */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Waktu Minum/Pakai *</Text>
          <View style={styles.inputContainer}>
            <Ionicons name="time-outline" size={20} color="#007AFF" />
            <TextInput
              style={styles.input}
              placeholder="Contoh: Setelah makan, sebelum tidur"
              value={usageTime}
              onChangeText={setUsageTime}
              placeholderTextColor="#C7C7CC"
            />
          </View>
        </View>

        {/* Times Per Day */}
        {renderTimesPerDaySelector()}

        {/* Alarm Times */}
        {renderAlarmTimes()}

        {/* Must Finish Switch */}
        <View style={styles.section}>
          <View style={styles.switchContainer}>
            <View style={styles.switchLeft}>
              <View style={styles.switchIcon}>
                <Ionicons name="checkmark-circle" size={24} color="#007AFF" />
              </View>
              <View style={styles.switchTextContainer}>
                <Text style={styles.sectionLabel}>Harus Dihabiskan?</Text>
                <Text style={styles.switchSubtext}>Obat harus diminum sampai habis</Text>
              </View>
            </View>
            <Switch
              value={mustFinish}
              onValueChange={setMustFinish}
              trackColor={{ false: "#E5E5EA", true: "#007AFF" }}
              thumbColor="#FFFFFF"
              ios_backgroundColor="#E5E5EA"
            />
          </View>
        </View>

        {/* Date Pickers */}
        {renderDatePicker("Tanggal Mulai *", startDate, setStartDate, showStartDatePicker, setShowStartDatePicker)}
        {renderDatePicker("Tanggal Selesai *", endDate, setEndDate, showEndDatePicker, setShowEndDatePicker)}

        {/* Save Button */}
        <TouchableOpacity style={styles.saveButtonContainer} onPress={saveMedicineSchedule}>
          <View style={styles.saveButton}>
            <Ionicons name="checkmark-circle" size={24} color="#FFFFFF" />
            <Text style={styles.saveButtonText}>Simpan Jadwal Obat</Text>
          </View>
        </TouchableOpacity>

        <View style={styles.bottomPadding} />
      </ScrollView>
    </View>
  );

  // Main render
  if (currentView === 'create') {
    return renderCreateForm();
  }
  
  if (currentView === 'detail') {
    return renderDetailView();
  }
  
  return renderMainScreen();
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8F9FA",
  },
  header: {
    paddingTop: Platform.OS === "ios" ? 60 : 40,
    paddingBottom: 30,
    paddingHorizontal: 20,
    backgroundColor: "#007AFF",
    borderBottomLeftRadius: 25,
    borderBottomRightRadius: 25,
    position: 'relative',
  },
  backButton: {
    position: 'absolute',
    top: Platform.OS === "ios" ? 60 : 40,
    left: 20,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  deleteButton: {
    position: 'absolute',
    top: Platform.OS === "ios" ? 60 : 40,
    right: 20,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255, 59, 48, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
    marginTop: -15,
    backgroundColor: "#F8F9FA",
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    paddingTop: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: "800",
    color: "#FFFFFF",
    marginBottom: 5,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: "#FFFFFF",
    opacity: 0.9,
    textAlign: 'center',
  },
  quickActionContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#007AFF',
    paddingVertical: 16,
    borderRadius: 16,
    ...Platform.select({
      ios: {
        shadowColor: "#007AFF",
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 8,
      },
      android: {
        elevation: 6,
      },
    }),
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '700',
    marginLeft: 8,
  },
  sectionContainer: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1D1D1F',
    marginHorizontal: 20,
    marginBottom: 12,
  },
  scheduleCard: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    marginBottom: 12,
    borderRadius: 16,
    padding: 16,
    ...Platform.select({
      ios: {
        shadowColor: "#000000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 8,
      },
      android: {
        elevation: 3,
      },
    }),
  },
  notesInput: {
    flex: 1,
    fontSize: 16,
    minHeight: 80,
    textAlignVertical: "top",
    color: "#1D1D1F",
    marginLeft: 12,
  },
  imageContainer: {
    backgroundColor: "#FFFFFF",
    borderRadius: 20,
    overflow: "hidden",
    ...Platform.select({
      ios: {
        shadowColor: "#000000",
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.1,
        shadowRadius: 12,
      },
      android: {
        elevation: 4,
      },
    }),
  },
  imageWrapper: {
    position: "relative",
  },
  medicineImage: {
    width: "100%",
    height: 200,
    resizeMode: "cover",
  },
  imageOverlay: {
    position: "absolute",
    top: 12,
    right: 12,
    backgroundColor: "rgba(0, 122, 255, 0.8)",
    borderRadius: 20,
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  imagePlaceholder: {
    height: 160,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F8F9FA",
  },
  cameraIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: "#E3F2FD",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 12,
  },
  imagePlaceholderText: {
    fontSize: 18,
    fontWeight: "600",
    color: "#1D1D1F",
    marginBottom: 4,
  },
  imagePlaceholderSubtext: {
    fontSize: 14,
    color: "#8E8E93",
  },
  saveButtonContainer: {
    marginHorizontal: 20,
    borderRadius: 16,
    overflow: "hidden",
    ...Platform.select({
      ios: {
        shadowColor: "#007AFF",
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 8,
      },
      android: {
        elevation: 6,
      },
    }),
  },
  saveButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#007AFF",
    paddingVertical: 18,
    paddingHorizontal: 24,
  },
  saveButtonText: {
    color: "#FFFFFF",
    fontSize: 18,
    fontWeight: "700",
    marginLeft: 8,
  },
  mustFinishText: {
    fontSize: 12,
    color: "#34C759",
    fontWeight: "600",
    marginLeft: 4,
  },
  bottomPadding: {
    height: 40,
  },
});
      },
      android: {
        elevation: 3,
      },
    }),
  },
  inactiveCard: {
    opacity: 0.6,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  cardHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  cardImage: {
    width: 48,
    height: 48,
    borderRadius: 8,
    marginRight: 12,
  },
  cardTitleContainer: {
    flex: 1,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1D1D1F',
    marginBottom: 2,
  },
  cardSubtitle: {
    fontSize: 14,
    color: '#8E8E93',
    marginBottom: 2,
  },
  nextTimeText: {
    fontSize: 14,
    color: '#007AFF',
    fontWeight: '600',
  },
  inactiveText: {
    fontSize: 14,
    color: '#8E8E93',
  },
  cardActions: {
    alignItems: 'flex-end',
  },
  takeButton: {
    backgroundColor: '#34C759',
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  timesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  timeBadge: {
    backgroundColor: '#F0F0F0',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  timeBadgeText: {
    fontSize: 14,
    color: '#1D1D1F',
    fontWeight: '600',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
    paddingVertical: 80,
  },
  emptyStateTitle: {
    fontSize: 24,
    fontWeight: "700",
    color: "#1D1D1F",
    marginTop: 16,
    marginBottom: 8,
    textAlign: 'center',
  },
  emptyStateSubtitle: {
    fontSize: 16,
    color: "#8E8E93",
    textAlign: 'center',
    lineHeight: 24,
  },
  detailImageContainer: {
    marginHorizontal: 20,
    marginBottom: 20,
    borderRadius: 16,
    overflow: 'hidden',
  },
  detailImage: {
    width: '100%',
    height: 200,
    resizeMode: 'cover',
  },
  detailContent: {
    paddingHorizontal: 20,
  },
  detailHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  detailTitle: {
    fontSize: 28,
    fontWeight: '800',
    color: '#1D1D1F',
    flex: 1,
    marginRight: 12,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  activeBadge: {
    backgroundColor: '#E8F5E8',
  },
  inactiveBadge: {
    backgroundColor: '#F0F0F0',
  },
  statusText: {
    fontSize: 14,
    fontWeight: '600',
  },
  activeText: {
    color: '#34C759',
  },
  inactiveStatusText: {
    color: '#8E8E93',
  },
  detailSection: {
    marginBottom: 24,
  },
  detailLabel: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1D1D1F',
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  detailKey: {
    fontSize: 16,
    color: '#8E8E93',
    flex: 1,
  },
  detailValue: {
    fontSize: 16,
    color: '#1D1D1F',
    fontWeight: '600',
    flex: 2,
    textAlign: 'right',
  },
  alarmTimesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  alarmTimeCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8F9FA',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
  },
  alarmTimeText: {
    fontSize: 16,
    color: '#1D1D1F',
    fontWeight: '600',
    marginLeft: 8,
  },
  dateRange: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#F8F9FA',
    padding: 16,
    borderRadius: 12,
  },
  dateRangeItem: {
    alignItems: 'center',
    flex: 1,
  },
  dateRangeLabel: {
    fontSize: 14,
    color: '#8E8E93',
    marginBottom: 4,
  },
  dateRangeValue: {
    fontSize: 16,
    color: '#1D1D1F',
    fontWeight: '600',
  },
  mustFinishContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F0FDF4',
    padding: 16,
    borderRadius: 12,
  },
  mustFinishDetailText: {
    fontSize: 16,
    color: '#34C759',
    fontWeight: '600',
    marginLeft: 12,
  },
  notesText: {
    fontSize: 16,
    color: '#1D1D1F',
    lineHeight: 24,
    backgroundColor: '#F8F9FA',
    padding: 16,
    borderRadius: 12,
  },
  lastTakenText: {
    fontSize: 16,
    color: '#1D1D1F',
    fontWeight: '600',
  },
  actionContainer: {
    marginTop: 12,
  },
  takenButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#34C759',
    paddingVertical: 16,
    borderRadius: 12,
  },
  takenButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '700',
    marginLeft: 8,
  },
  section: {
    marginHorizontal: 20,
    marginBottom: 20,
  },
  sectionLabel: {
    fontSize: 17,
    fontWeight: "600",
    color: "#1D1D1F",
    marginBottom: 12,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 4,
    ...Platform.select({
      ios: {
        shadowColor: "#000000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 8,
      },
      android: {
        elevation: 3,
      },
    }),
  },
  input: {
    flex: 1,
    fontSize: 16,
    paddingVertical: 16,
    color: "#1D1D1F",
    marginLeft: 12,
  },
  unitText: {
    fontSize: 16,
    color: "#8E8E93",
    marginLeft: 8,
  },
  dosageContainer: {
    gap: 12,
  },
  pickerWrapper: {
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    overflow: "hidden",
    ...Platform.select({
      ios: {
        shadowColor: "#000000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 8,
      },
      android: {
        elevation: 3,
      },
    }),
  },
  frequencyContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  frequencyButton: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: "#FFFFFF",
    borderWidth: 2,
    borderColor: "#E5E5EA",
    minWidth: 50,
    alignItems: 'center',
  },
  frequencyButtonActive: {
    backgroundColor: "#007AFF",
    borderColor: "#007AFF",
  },
  frequencyButtonText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#1D1D1F",
  },
  frequencyButtonTextActive: {
    color: "#FFFFFF",
  },
  alarmTimeContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    paddingHorizontal: 20,
    paddingVertical: 16,
    marginBottom: 12,
    ...Platform.select({
      ios: {
        shadowColor: "#000000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 8,
      },
      android: {
        elevation: 3,
      },
    }),
  },
  timeDisplayContainer: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  timeIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "#E3F2FD",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
  },
  timeInfo: {
    flex: 1,
  },
  timeText: {
    fontSize: 18,
    fontWeight: "600",
    color: "#1D1D1F",
  },
  timeSubtext: {
    fontSize: 14,
    color: "#8E8E93",
    marginTop: 2,
  },
  actionButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "#F8F9FA",
    justifyContent: "center",
    alignItems: "center",
  },
  switchContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    paddingHorizontal: 20,
    paddingVertical: 16,
    ...Platform.select({
      ios: {
        shadowColor: "#000000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 8,
      },
      android: {
        elevation: 3,
      },
    }),
  },
  switchLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  switchIcon: {
    marginRight: 12,
  },
  switchTextContainer: {
    flex: 1,
  },
  switchSubtext: {
    fontSize: 14,
    color: "#8E8E93",
    marginTop: 2,
  },
  dateButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 16,
    ...Platform.select({
      ios: {
        shadowColor: "#000000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 8,
      },
      android: {
        elevation: 3,
      },
    }),
  },
  dateButtonContent: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  dateButtonText: {
    fontSize: 16,
    color: "#1D1D1F",
    marginLeft: 12,
    flex: 1,
  },
  webInputContainer: {
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    ...Platform.select({
      ios: {
        shadowColor: "#000000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 8,
      },
      android: {
        elevation: 3,
      },
    }),
  },
  notesContainer: {
    flexDirection: "row",
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    padding: 16,
    alignItems: "flex-start",
    ...Platform.select({
      ios: {
        shadowColor: "#000000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 8,
      },
      android: {
        elevation: 4,
      },
    }),
  },
  